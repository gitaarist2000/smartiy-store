<?php
/* Smarty version 3.1.34-dev-7, created on 2020-09-12 22:05:54
  from '/laravel/templates/admin/orders.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f5d1c12ad9002_91163605',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7171b6253ea6e1e1178fd28505d65d970db53f2a' => 
    array (
      0 => '/laravel/templates/admin/orders.tpl',
      1 => 1599763265,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f5d1c12ad9002_91163605 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6614707235f5d1c12ad84e2_09092861', "body");
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "layout.tpl");
}
/* {block "body"} */
class Block_6614707235f5d1c12ad84e2_09092861 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_6614707235f5d1c12ad84e2_09092861',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    LIST OF ALL USERS ORDERS
<?php
}
}
/* {/block "body"} */
}
